const readline = require('readline');
const bcrypt = require('bcrypt');
const { connectDb, client } = require('./db');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function ask(question) {
  return new Promise((resolve) => rl.question(question, resolve));
}

async function main() {
  try {
    const db = await connectDb();
    const username = (await ask('Admin username: ')).trim();
    const email = (await ask('Admin email: ')).trim().toLowerCase();
    const password = await ask('Admin password: ');

    if (!/^[a-zA-Z0-9_]{3,30}$/.test(username)) {
      throw new Error('Username must be 3–30 letters, numbers, or underscores.');
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      throw new Error('Please enter a valid email address.');
    }

    if (password.length < 8 || password.length > 72) {
      throw new Error('Password must be between 8 and 72 characters.');
    }

    const existing = await db.collection('users').findOne({ role: 'admin' });
    if (existing) {
      throw new Error('An admin account already exists. No account was changed.');
    }

    const passwordHash = await bcrypt.hash(password, 12);
    await db.collection('users').insertOne({
      username,
      email,
      password_hash: passwordHash,
      role: 'admin',
      createdAt: new Date(),
    });

    console.log(`Admin account "${username}" created successfully in MongoDB.`);
  } catch (error) {
    console.error('Admin setup failed:', error.message);
    process.exitCode = 1;
  } finally {
    rl.close();
    await client.close();
  }
}

main();
