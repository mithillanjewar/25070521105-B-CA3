const { MongoClient, ObjectId } = require('mongodb');

const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017';
const client = new MongoClient(uri);

let db = null;

async function connectDb() {
  if (!db) {
    await client.connect();
    const dbName = process.env.DB_NAME || 'chess_arena';
    db = client.db(dbName);
    console.log(`Connected successfully to MongoDB database: ${dbName}`);

    // Create unique indexes
    try {
      await db.collection('users').createIndex({ username: 1 }, { unique: true });
      await db.collection('users').createIndex({ email: 1 }, { unique: true });
      await db.collection('games').createIndex({ user_id: 1, createdAt: -1 });
    } catch (e) {
      console.warn('Index notice:', e.message);
    }
  }
  return db;
}

module.exports = {
  client,
  connectDb,
  getDb: () => db,
  ObjectId,
};
