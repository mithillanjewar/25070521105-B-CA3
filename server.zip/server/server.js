const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');
require('dotenv').config({ path: path.join(__dirname, '.env') });
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const { connectDb, ObjectId } = require('./db');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'chess_arena_super_secret_jwt_key_2026_xyz_production_dev_random_key_12345';

let db = null;

const CLIENT_ORIGINS = (process.env.CLIENT_ORIGIN || 'http://localhost:5173,http://localhost:5000')
  .split(',')
  .map((origin) => origin.trim());

app.use(cors({ origin: CLIENT_ORIGINS }));
app.use(express.json({ limit: '50kb' }));

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'Chess Arena API is running with MongoDB Compass database',
    database: db ? db.databaseName : 'connecting...',
  });
});

// Registration
app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (
      typeof username !== 'string' ||
      typeof email !== 'string' ||
      typeof password !== 'string'
    ) {
      return res.status(400).json({ message: 'Please fill in all fields.' });
    }

    const cleanUsername = username.trim();
    const cleanEmail = email.trim().toLowerCase();

    if (
      cleanUsername.length < 3 ||
      cleanUsername.length > 30 ||
      !/^[a-zA-Z0-9_]+$/.test(cleanUsername)
    ) {
      return res.status(400).json({
        message: 'Username must be 3–30 characters using letters, numbers, or underscores.',
      });
    }

    if (
      cleanEmail.length > 254 ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)
    ) {
      return res.status(400).json({ message: 'Enter a valid email address.' });
    }

    if (password.length < 8 || password.length > 72) {
      return res.status(400).json({
        message: 'Password must be between 8 and 72 characters.',
      });
    }

    const existingUser = await db.collection('users').findOne({
      $or: [
        { username: { $regex: new RegExp(`^${cleanUsername}$`, 'i') } },
        { email: cleanEmail },
      ],
    });

    if (existingUser) {
      return res.status(409).json({
        message: 'That username or email is already registered in MongoDB.',
      });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const result = await db.collection('users').insertOne({
      username: cleanUsername,
      email: cleanEmail,
      password_hash: passwordHash,
      role: 'user',
      createdAt: new Date(),
    });

    res.status(201).json({
      message: 'Account created successfully. You can now log in.',
      user: {
        id: result.insertedId.toString(),
        username: cleanUsername,
        email: cleanEmail,
        role: 'user',
      },
    });
  } catch (error) {
    console.error('Registration error:', error.message);
    res.status(500).json({ message: 'Could not create account in MongoDB.' });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { identifier, password, role } = req.body;

    if (
      typeof identifier !== 'string' ||
      typeof password !== 'string' ||
      !['user', 'admin'].includes(role)
    ) {
      return res.status(400).json({ message: 'Invalid login request.' });
    }

    const cleanIdentifier = identifier.trim();

    const account = await db.collection('users').findOne({
      $or: [
        { username: { $regex: new RegExp(`^${cleanIdentifier}$`, 'i') } },
        { email: cleanIdentifier.toLowerCase() },
      ],
    });

    if (!account) {
      return res.status(401).json({
        message: 'Invalid credentials or access type.',
      });
    }

    const passwordMatches = await bcrypt.compare(password, account.password_hash);

    if (!passwordMatches || account.role !== role) {
      return res.status(401).json({
        message: 'Invalid credentials or access type.',
      });
    }

    const token = jwt.sign(
      { sub: account._id.toString(), role: account.role },
      JWT_SECRET,
      { expiresIn: '4h' }
    );

    res.json({
      message: 'Login successful.',
      token,
      user: {
        id: account._id.toString(),
        username: account.username,
        email: account.email,
        role: account.role,
      },
    });
  } catch (error) {
    console.error('Login error:', error.message);
    res.status(500).json({ message: 'Could not log in.' });
  }
});

// Auth Middleware
async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ message: 'Please log in.' });
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const account = await db.collection('users').findOne({
      _id: new ObjectId(payload.sub),
    });

    if (!account || account.role !== payload.role) {
      return res.status(401).json({ message: 'Invalid session.' });
    }

    req.account = {
      id: account._id.toString(),
      username: account.username,
      email: account.email,
      role: account.role,
      createdAt: account.createdAt,
    };
    next();
  } catch {
    res.status(401).json({ message: 'Session expired or invalid.' });
  }
}

function requireAdmin(req, res, next) {
  if (req.account?.role !== 'admin') {
    return res.status(403).json({ message: 'Administrator access required.' });
  }
  next();
}

app.get('/api/auth/me', requireAuth, (req, res) => {
  res.json({ user: req.account });
});

// ---------- Games ----------
const GAME_RESULTS = ['win', 'loss', 'draw', 'white', 'black'];
const GAME_REASONS = [
  'checkmate', 'stalemate', 'insufficient material', 'threefold repetition',
  'fifty-move rule', 'draw', 'resignation',
];

app.post('/api/games', requireAuth, async (req, res) => {
  try {
    const { mode, difficulty, playerColor, result, reason, moves, pgn } = req.body || {};

    if (!['ai', 'local'].includes(mode)) {
      return res.status(400).json({ message: 'Invalid game mode.' });
    }
    if (mode === 'ai' && !['easy', 'medium', 'hard'].includes(difficulty)) {
      return res.status(400).json({ message: 'Invalid difficulty.' });
    }
    if (mode === 'ai' && !['w', 'b'].includes(playerColor)) {
      return res.status(400).json({ message: 'Invalid player color.' });
    }
    if (!GAME_RESULTS.includes(result) || !GAME_REASONS.includes(reason)) {
      return res.status(400).json({ message: 'Invalid game result.' });
    }
    if (!Number.isInteger(moves) || moves < 0 || moves > 2000) {
      return res.status(400).json({ message: 'Invalid move count.' });
    }
    if (pgn !== undefined && (typeof pgn !== 'string' || pgn.length > 6000)) {
      return res.status(400).json({ message: 'Invalid PGN.' });
    }

    const info = await db.collection('games').insertOne({
      user_id: new ObjectId(req.account.id),
      username: req.account.username,
      mode,
      difficulty: mode === 'ai' ? difficulty : null,
      player_color: mode === 'ai' ? playerColor : null,
      result,
      reason,
      moves,
      pgn: pgn || null,
      createdAt: new Date(),
    });

    res.status(201).json({ id: info.insertedId.toString() });
  } catch (error) {
    console.error('Save game error:', error.message);
    res.status(500).json({ message: 'Could not save game in MongoDB.' });
  }
});

app.get('/api/games/me', requireAuth, async (req, res) => {
  try {
    const rawGames = await db
      .collection('games')
      .find({ user_id: new ObjectId(req.account.id) })
      .sort({ createdAt: -1 })
      .limit(25)
      .toArray();

    const games = rawGames.map((g) => ({
      id: g._id.toString(),
      mode: g.mode,
      difficulty: g.difficulty,
      playerColor: g.player_color,
      result: g.result,
      reason: g.reason,
      moves: g.moves,
      createdAt: g.createdAt,
    }));

    const played = await db
      .collection('games')
      .countDocuments({ user_id: new ObjectId(req.account.id) });
    const wins = await db
      .collection('games')
      .countDocuments({ user_id: new ObjectId(req.account.id), result: 'win' });
    const losses = await db
      .collection('games')
      .countDocuments({ user_id: new ObjectId(req.account.id), result: 'loss' });
    const draws = await db
      .collection('games')
      .countDocuments({ user_id: new ObjectId(req.account.id), result: 'draw' });

    res.json({
      games,
      stats: { played, wins, losses, draws },
    });
  } catch (error) {
    console.error('Fetch games error:', error.message);
    res.status(500).json({ message: 'Could not fetch games from MongoDB.' });
  }
});

// ---------- Admin ----------
app.get('/api/admin/stats', requireAuth, requireAdmin, async (req, res) => {
  try {
    const players = await db.collection('users').countDocuments({ role: 'user' });
    const games = await db.collection('games').countDocuments();
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const today = await db.collection('games').countDocuments({ createdAt: { $gte: oneDayAgo } });
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const newPlayers = await db.collection('users').countDocuments({
      role: 'user',
      createdAt: { $gte: oneWeekAgo },
    });

    res.json({ players, games, gamesToday: today, newPlayersThisWeek: newPlayers });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.get('/api/admin/users', requireAuth, requireAdmin, async (req, res) => {
  try {
    const users = await db.collection('users').aggregate([
      {
        $lookup: {
          from: 'games',
          localField: '_id',
          foreignField: 'user_id',
          as: 'userGames',
        },
      },
      {
        $project: {
          id: { $toString: '$_id' },
          username: 1,
          email: 1,
          role: 1,
          createdAt: 1,
          games: { $size: '$userGames' },
          wins: {
            $size: {
              $filter: {
                input: '$userGames',
                as: 'g',
                cond: { $eq: ['$$g.result', 'win'] },
              },
            },
          },
        },
      },
      { $sort: { createdAt: -1 } },
      { $limit: 200 },
    ]).toArray();

    res.json({ users });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Serve frontend build if available
const clientDist = path.join(__dirname, '..', 'client', 'dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.use((req, res, next) => {
    if (req.method !== 'GET' || req.path.startsWith('/api/')) return next();
    res.sendFile(path.join(clientDist, 'index.html'));
  });
}

app.use('/api', (req, res) => {
  res.status(404).json({ message: 'Not found.' });
});

async function startServer() {
  try {
    db = await connectDb();

    // Auto-seed demo admin if none exists
    const adminCount = await db.collection('users').countDocuments({ role: 'admin' });
    if (adminCount === 0) {
      const adminPass = await bcrypt.hash('admin12345', 12);
      await db.collection('users').insertOne({
        username: 'admin',
        email: 'admin@chessarena.org',
        password_hash: adminPass,
        role: 'admin',
        createdAt: new Date(),
      });
      console.log('Demo admin created: username="admin", password="admin12345"');
    }

    app.listen(PORT, () => {
      console.log(`Chess Arena API (MongoDB) running at http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

startServer();
