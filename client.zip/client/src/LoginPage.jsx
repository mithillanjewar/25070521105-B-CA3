import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Header from './homeComp/header';
import Footer from './homeComp/footer';
import MainContentCont from './homeComp/mainContentCont';
import { api } from './api';
import './App.css';

const LoginPage = ({ user, onLogin, onGuest, onSignOut }) => {
  const navigate = useNavigate();
  const [tab, setTab] = useState('user'); // 'user' | 'admin'
  const [isRegistering, setIsRegistering] = useState(false);

  // Login form state
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Register form state
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirm, setRegConfirm] = useState('');
  const [regLoading, setRegLoading] = useState(false);
  const [regError, setRegError] = useState('');
  const [regSuccess, setRegSuccess] = useState('');

  // Quick fill helper
  const quickFill = (uname, pass, role) => {
    setTab(role);
    setIsRegistering(false);
    setIdentifier(uname);
    setPassword(pass);
    setLoginError('');
  };

  // Submit Login
  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setLoginError('');
    setLoginLoading(true);

    try {
      const data = await api('/auth/login', {
        method: 'POST',
        token: null,
        body: {
          identifier: identifier.trim(),
          password,
          role: tab,
        },
      });

      if (!data.user) {
        throw new Error('Invalid response received from server.');
      }

      onLogin(data);
      navigate('/');
    } catch (err) {
      setLoginError(err.message || 'Login failed. Please verify your credentials and selected tab.');
    } finally {
      setLoginLoading(false);
    }
  };

  // Submit Register
  const handleRegisterSubmit = async (e) => {
    e.preventDefault();
    setRegError('');
    setRegSuccess('');

    if (regPassword.length < 8) {
      setRegError('Password must be at least 8 characters long.');
      return;
    }
    if (regPassword !== regConfirm) {
      setRegError('Passwords do not match.');
      return;
    }

    setRegLoading(true);
    try {
      const data = await api('/auth/register', {
        method: 'POST',
        token: null,
        body: {
          username: regUsername.trim(),
          email: regEmail.trim(),
          password: regPassword,
        },
      });

      setRegSuccess(data.message || 'Account created successfully! You can now sign in.');
      setIdentifier(regUsername.trim());
      setPassword(regPassword);
      setTab('user');
      setIsRegistering(false);
      setRegUsername('');
      setRegEmail('');
      setRegPassword('');
      setRegConfirm('');
    } catch (err) {
      setRegError(err.message || 'Registration failed. Username or email may already be registered.');
    } finally {
      setRegLoading(false);
    }
  };

  const handleGuestPlay = () => {
    onGuest();
    navigate('/');
  };

  return (
    <div style={{ background: '#07090e', color: '#e2e8f0', minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header user={user} onSignOut={onSignOut} />

      <MainContentCont>
        <div className="container py-4 my-auto">
          {user ? (
            /* Already logged in view */
            <div className="row justify-content-center">
              <div className="col-md-7">
                <div className="card border-0 shadow-lg p-5 text-center" style={{ background: '#121726', borderRadius: 16 }}>
                  <span style={{ fontSize: '3.5rem' }}>♞</span>
                  <h3 className="text-white font-weight-bold mt-3">Already Signed In</h3>
                  <p className="text-muted">
                    You are logged in as <strong className="text-warning">{user.username}</strong> ({user.email}) with role <span className="badge badge-primary">{user.role}</span>.
                  </p>
                  <div className="d-flex justify-content-center gap-3 mt-4">
                    <button className="btn btn-warning font-weight-bold px-4 py-2 mr-3" onClick={() => navigate('/')}>
                      Go to Arena Dashboard →
                    </button>
                    <button className="btn btn-outline-danger px-4 py-2" onClick={onSignOut}>
                      Sign Out
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Sign in / Register view */
            <div className="row align-items-center justify-content-center">
              {/* Left Column: Information & Quick Access */}
              <div className="col-lg-5 mb-5 mb-lg-0 pr-lg-4">
                <span className="badge badge-warning font-weight-bold px-3 py-1 mb-2">AUTHENTICATION GATEWAY</span>
                <h1 className="display-5 font-weight-bold text-white mb-3">
                  Step into <em>the arena.</em>
                </h1>
                <p className="text-muted lead mb-4">
                  Sign in with MongoDB credentials to record your matches, view real-time engine telemetry, and build your legacy.
                </p>

                <div className="p-3 mb-4 rounded border border-secondary" style={{ background: '#111624' }}>
                  <h6 className="text-warning font-weight-bold mb-2">⚡ Quick-Fill Demo Credentials:</h6>
                  <div className="d-flex flex-wrap gap-2 mb-2">
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-warning mr-2 mb-2 font-weight-bold"
                      onClick={() => quickFill('mithil_lanjewar', 'password123', 'user')}
                    >
                      👤 Mithil Lanjewar (Player)
                    </button>
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-info mr-2 mb-2 font-weight-bold"
                      onClick={() => quickFill('admin', 'admin12345', 'admin')}
                    >
                      🛡️ Administrator (Admin)
                    </button>
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-light mb-2 font-weight-bold"
                      onClick={() => quickFill('grandmaster_somesh', 'password123', 'user')}
                    >
                      ♟️ GM Somesh (Player)
                    </button>
                  </div>
                  <small className="text-muted d-block">
                    Click any badge above to prefill credentials and switch to the correct tab.
                  </small>
                </div>

                <div className="d-flex align-items-center">
                  <span className="text-muted mr-3">Or skip authentication:</span>
                  <button type="button" className="btn btn-outline-secondary btn-sm" onClick={handleGuestPlay}>
                    Play as guest →
                  </button>
                </div>
              </div>

              {/* Right Column: Card with Tabs & Form */}
              <div className="col-lg-6 col-md-8">
                <div
                  className="card border border-secondary shadow-lg p-4 p-md-5"
                  style={{
                    background: '#121726',
                    borderRadius: '20px',
                    boxShadow: '0 20px 50px rgba(0,0,0,0.6)',
                  }}
                >
                  {/* Status Alerts */}
                  {regSuccess && (
                    <div className="alert alert-success alert-dismissible fade show" role="alert">
                      <strong>Success!</strong> {regSuccess}
                    </div>
                  )}

                  {!isRegistering ? (
                    /* LOGIN FORM */
                    <div>
                      {/* Tabs */}
                      <div className="d-flex mb-4 p-1 rounded" style={{ background: '#0a0d14' }}>
                        <button
                          type="button"
                          className={`btn flex-fill font-weight-bold py-2 ${
                            tab === 'user' ? 'btn-warning text-dark' : 'btn-dark text-muted'
                          }`}
                          onClick={() => {
                            setTab('user');
                            setLoginError('');
                          }}
                        >
                          👤 Player
                        </button>
                        <button
                          type="button"
                          className={`btn flex-fill font-weight-bold py-2 ${
                            tab === 'admin' ? 'btn-warning text-dark' : 'btn-dark text-muted'
                          }`}
                          onClick={() => {
                            setTab('admin');
                            setLoginError('');
                          }}
                        >
                          🛡️ Admin
                        </button>
                      </div>

                      <div className="mb-3">
                        <h4 className="text-white font-weight-bold mb-1">
                          {tab === 'admin' ? 'Administrator Control Room' : 'Return to the Arena'}
                        </h4>
                        <p className="text-muted small">
                          {tab === 'admin'
                            ? 'Sign in with administrator credentials.'
                            : 'Sign in to track your finished matches and statistics.'}
                        </p>
                      </div>

                      {loginError && (
                        <div className="alert alert-danger py-2 small mb-3" role="alert">
                          {loginError}
                        </div>
                      )}

                      <form onSubmit={handleLoginSubmit}>
                        <div className="form-group mb-3">
                          <label className="text-muted small text-uppercase font-weight-bold">
                            Email or Username
                          </label>
                          <input
                            type="text"
                            className="form-control bg-dark border-secondary text-white py-2"
                            required
                            placeholder={tab === 'admin' ? 'e.g. admin' : 'e.g. mithil_lanjewar'}
                            value={identifier}
                            onChange={(e) => setIdentifier(e.target.value)}
                            autoComplete="username"
                          />
                        </div>

                        <div className="form-group mb-4">
                          <label className="text-muted small text-uppercase font-weight-bold">Password</label>
                          <input
                            type="password"
                            className="form-control bg-dark border-secondary text-white py-2"
                            required
                            placeholder="Enter password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            autoComplete="current-password"
                          />
                        </div>

                        <button
                          type="submit"
                          className="btn btn-warning btn-block font-weight-bold py-2 shadow-sm"
                          disabled={loginLoading}
                          style={{ fontSize: '1rem', letterSpacing: '0.5px' }}
                        >
                          {loginLoading ? 'Signing in...' : tab === 'admin' ? 'Enter Control Room →' : 'Enter the Arena →'}
                        </button>
                      </form>

                      {tab === 'user' && (
                        <div className="mt-4 text-center border-top border-secondary pt-3">
                          <span className="text-muted small">New to Chess Arena? </span>
                          <button
                            type="button"
                            className="btn btn-link text-warning p-0 small font-weight-bold"
                            onClick={() => {
                              setIsRegistering(true);
                              setRegError('');
                            }}
                          >
                            Create an account
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    /* REGISTRATION FORM */
                    <div>
                      <div className="d-flex justify-content-between align-items-center mb-3">
                        <h4 className="text-white font-weight-bold mb-0">Create Player Account</h4>
                        <button
                          type="button"
                          className="btn btn-sm btn-outline-secondary"
                          onClick={() => {
                            setIsRegistering(false);
                            setRegError('');
                          }}
                        >
                          ← Back to Login
                        </button>
                      </div>
                      <p className="text-muted small mb-3">
                        Register in MongoDB to record games, ratings, and stats.
                      </p>

                      {regError && (
                        <div className="alert alert-danger py-2 small mb-3" role="alert">
                          {regError}
                        </div>
                      )}

                      <form onSubmit={handleRegisterSubmit}>
                        <div className="form-group mb-3">
                          <label className="text-muted small text-uppercase font-weight-bold">Username</label>
                          <input
                            type="text"
                            className="form-control bg-dark border-secondary text-white"
                            required
                            placeholder="e.g. player_one"
                            value={regUsername}
                            onChange={(e) => setRegUsername(e.target.value)}
                          />
                        </div>

                        <div className="form-group mb-3">
                          <label className="text-muted small text-uppercase font-weight-bold">Email Address</label>
                          <input
                            type="email"
                            className="form-control bg-dark border-secondary text-white"
                            required
                            placeholder="e.g. player@sitnagpur.edu.in"
                            value={regEmail}
                            onChange={(e) => setRegEmail(e.target.value)}
                          />
                        </div>

                        <div className="form-row">
                          <div className="form-group col-md-6 mb-3">
                            <label className="text-muted small text-uppercase font-weight-bold">Password</label>
                            <input
                              type="password"
                              className="form-control bg-dark border-secondary text-white"
                              required
                              placeholder="At least 8 chars"
                              value={regPassword}
                              onChange={(e) => setRegPassword(e.target.value)}
                            />
                          </div>
                          <div className="form-group col-md-6 mb-3">
                            <label className="text-muted small text-uppercase font-weight-bold">Confirm</label>
                            <input
                              type="password"
                              className="form-control bg-dark border-secondary text-white"
                              required
                              placeholder="Confirm password"
                              value={regConfirm}
                              onChange={(e) => setRegConfirm(e.target.value)}
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          className="btn btn-warning btn-block font-weight-bold py-2 mt-2 shadow-sm"
                          disabled={regLoading}
                        >
                          {regLoading ? 'Creating Account in MongoDB...' : 'Register & Enter Arena →'}
                        </button>
                      </form>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </MainContentCont>

      <Footer />
    </div>
  );
};

export default LoginPage;
