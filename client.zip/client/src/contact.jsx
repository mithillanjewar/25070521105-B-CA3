import React, { useState } from 'react';
import Header from './homeComp/header';
import Footer from './homeComp/footer';
import MainContentCont from './homeComp/mainContentCont';

const Contact = ({ user, onSignOut }) => {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    setFormData({ name: '', email: '', subject: '', message: '' });
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div style={{ background: '#0a0d14', color: '#e2e8f0', minHeight: '100vh' }}>
      <Header user={user} onSignOut={onSignOut} />
      <MainContentCont>
        <div className="container py-5">
          <div className="p-4 p-md-5 rounded shadow-lg border border-secondary" style={{ background: '#121726' }}>
            <span className="badge badge-warning px-3 py-1 mb-2 font-weight-bold">SUPPORT &amp; INQUIRIES</span>
            <h1 className="display-5 font-weight-bold text-white mb-4">Contact &amp; Submission Desk</h1>

            {submitted && (
              <div className="alert alert-success border-0 shadow-sm" role="alert">
                <strong>Message Dispatched!</strong> Your inquiry has been forwarded to the course instructor.
              </div>
            )}

            <div className="row">
              <div className="col-md-7 mb-4 mb-md-0">
                <form onSubmit={handleSubmit}>
                  <div className="form-group mb-3">
                    <label className="text-muted small text-uppercase font-weight-bold">Full Name</label>
                    <input
                      type="text"
                      className="form-control bg-dark border-secondary text-white"
                      required
                      placeholder="Enter your name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>

                  <div className="form-group mb-3">
                    <label className="text-muted small text-uppercase font-weight-bold">Email Address</label>
                    <input
                      type="email"
                      className="form-control bg-dark border-secondary text-white"
                      required
                      placeholder="student@sitnagpur.edu.in"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>

                  <div className="form-group mb-3">
                    <label className="text-muted small text-uppercase font-weight-bold">Subject</label>
                    <input
                      type="text"
                      className="form-control bg-dark border-secondary text-white"
                      required
                      placeholder="e.g. CA-03 Submission Query or Bug Report"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    />
                  </div>

                  <div className="form-group mb-4">
                    <label className="text-muted small text-uppercase font-weight-bold">Message</label>
                    <textarea
                      className="form-control bg-dark border-secondary text-white"
                      rows="4"
                      required
                      placeholder="Write your message or inquiry..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    ></textarea>
                  </div>

                  <button type="submit" className="btn btn-warning font-weight-bold px-4 py-2">
                    Send Inquiry
                  </button>
                </form>
              </div>

              <div className="col-md-5">
                <div className="p-4 rounded border border-secondary h-100" style={{ background: '#171e31' }}>
                  <h5 className="text-white font-weight-bold mb-3">Academic Coordinator</h5>
                  <div className="mb-3">
                    <p className="mb-1 text-warning font-weight-bold">Prof. Somesh Chutel</p>
                    <p className="text-muted small mb-0">Department of Computer Science &amp; Information Technology</p>
                    <p className="text-muted small mb-0">Symbiosis Institute of Technology (SIT), Section B</p>
                  </div>

                  <hr className="border-secondary my-3" />

                  <h6 className="text-white font-weight-bold mb-2">Continuous Assessment 03</h6>
                  <p className="text-muted small mb-1">
                    <strong>Student Name:</strong> Mithil Lanjewar
                  </p>
                  <p className="text-muted small mb-1">
                    <strong>Submission ID:</strong> <code>25070521105-CA-03</code>
                  </p>
                  <p className="text-muted small mb-3">
                    <strong>Student PRN:</strong> <code>25070521105</code>
                  </p>

                  <h6 className="text-white font-weight-bold mb-2">MongoDB Compass Server</h6>
                  <p className="text-muted small mb-0">
                    Host: <code>127.0.0.1:27017</code><br />
                    Database: <code>chess_arena</code><br />
                    Collections: <code>users</code>, <code>games</code>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </MainContentCont>
      <Footer />
    </div>
  );
};

export default Contact;
