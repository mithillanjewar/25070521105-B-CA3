import React, { useState, useEffect, useCallback } from 'react';
import Header from './homeComp/header';
import Footer from './homeComp/footer';
import MainContentCont from './homeComp/mainContentCont';
import ChessGame from './ChessGame';
import Landing from './components/Landing.jsx';
import { AdminDashboard, UserDashboard } from './components/Dashboards.jsx';
import { CinematicIntro } from './components/effects.jsx';
import { api, getToken, setToken } from './api.js';
import './App.css';

function introSeen() {
  try {
    return sessionStorage.getItem('chessArenaIntro') === '1';
  } catch {
    return false;
  }
}

const Home = ({ user, setUser, token, setTok, signOut }) => {
  const [checking, setChecking] = useState(() => Boolean(getToken()));
  const [view, setView] = useState('home'); // 'home' | 'game'
  const [gameConfig, setGameConfig] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [showIntro, setShowIntro] = useState(() => !introSeen());
  const [curtain, setCurtain] = useState(false);

  useEffect(() => {
    if (!token) {
      setChecking(false);
      return;
    }
    api('/auth/me', { token })
      .then((data) => setUser(data.user))
      .catch(() => {
        setToken(null);
        setTok(null);
        setUser(null);
      })
      .finally(() => setChecking(false));
  }, [token, setTok, setUser]);

  const endIntro = useCallback(() => {
    setShowIntro(false);
    try {
      sessionStorage.setItem('chessArenaIntro', '1');
    } catch {
      /* ignore */
    }
  }, []);

  function transition(fn) {
    setCurtain(true);
    setTimeout(() => {
      fn();
      window.scrollTo({ top: 0 });
      setTimeout(() => setCurtain(false), 60);
    }, 420);
  }

  function handleLogin(data) {
    transition(() => {
      setToken(data.token);
      setTok(data.token);
      setUser(data.user);
      setView('home');
    });
  }

  function play(config) {
    transition(() => {
      setGameConfig(
        config && config.mode === 'ai' && !config.color ? { ...config, color: 'w' } : config
      );
      setView('game');
    });
  }

  function leaveGame() {
    transition(() => setView('home'));
  }

  let screen;
  if (checking) {
    screen = (
      <div className="loading-screen py-5 text-center">
        <span className="brand-mark spin" style={{ fontSize: '3rem' }}>♞</span>
        <p className="mt-3 text-muted">Connecting to MongoDB database...</p>
      </div>
    );
  } else if (view === 'game') {
    screen = (
      <ChessGame
        token={user ? token : null}
        initialConfig={gameConfig && gameConfig.mode === 'local' ? { mode: 'local' } : gameConfig}
        onBack={leaveGame}
        onSaved={() => setRefreshKey((k) => k + 1)}
      />
    );
  } else if (user) {
    screen =
      user.role === 'admin' ? (
        <AdminDashboard user={user} token={token} onSignOut={signOut} onPlay={play} />
      ) : (
        <UserDashboard user={user} token={token} onSignOut={signOut} onPlay={play} refreshKey={refreshKey} />
      );
  } else {
    screen = <Landing onLogin={handleLogin} onGuest={() => play(null)} />;
  }

  return (
    <div className="home-arena-wrapper">
      <Header user={user} onSignOut={signOut} />
      <MainContentCont>
        <div className="grain" aria-hidden="true" />
        {screen}
        <div className={`scene-cut ${curtain ? 'on' : ''}`} aria-hidden="true" />
        {showIntro && !user && !checking && <CinematicIntro onDone={endIntro} />}
      </MainContentCont>
      <Footer />
    </div>
  );
};

export default Home;
