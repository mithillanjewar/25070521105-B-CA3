import React from 'react';

const MainContentCont = ({ children }) => {
  return (
    <div className="main-content-cont">
      {children}
    </div>
  );
};

export default MainContentCont;
