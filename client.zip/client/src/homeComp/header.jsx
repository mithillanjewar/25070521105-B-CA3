import React from 'react';
import { Link } from 'react-router-dom';

const Header = ({ user, onSignOut }) => {
  return (
    <header className="sit-header py-3 px-4 shadow-sm border-bottom border-dark" style={{ background: '#0b0f19', color: '#fff' }}>
      <div className="container-fluid d-flex flex-wrap align-items-center justify-content-between">
        <div className="d-flex align-items-center">
          <Link to="/" className="text-decoration-none d-flex align-items-center mr-3">
            <span style={{ fontSize: '2rem', marginRight: '10px' }}>♞</span>
            <div>
              <h4 className="mb-0 font-weight-bold text-warning" style={{ letterSpacing: '1px' }}>
                CHESS ARENA
              </h4>
              <small className="text-muted">
                SIT Section B &bull; Mithil Lanjewar (25070521105) &bull; CA-03
              </small>
            </div>
          </Link>
        </div>

        <div className="d-flex align-items-center my-2 my-md-0">
          <span className="badge badge-dark border border-secondary px-3 py-2 mr-2 text-monospace small text-light">
            <span className="d-inline-block rounded-circle bg-success mr-2" style={{ width: 8, height: 8 }}></span>
            MongoDB Compass : 27017 (chess_arena)
          </span>

          {user ? (
            <div className="d-flex align-items-center">
              <span className="badge badge-primary px-3 py-2 mr-2">
                👤 {user.username} ({user.role})
              </span>
              <button className="btn btn-sm btn-outline-danger" onClick={onSignOut}>
                Sign Out
              </button>
            </div>
          ) : (
            <div className="d-flex align-items-center">
              <Link to="/login" className="btn btn-sm btn-warning font-weight-bold mr-2">
                Sign In / Login
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
