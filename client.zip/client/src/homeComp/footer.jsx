import React from 'react';

const Footer = () => {
  return (
    <footer className="sit-footer py-4 border-top border-secondary" style={{ background: '#0a0d14', color: '#8892b0' }}>
      <div className="container">
        <div className="row align-items-center">
          <div className="col-md-6 text-center text-md-left mb-3 mb-md-0">
            <h6 className="font-weight-bold text-white mb-1">
              ♞ Chess Arena &bull; Web Technologies Lab CA-03
            </h6>
            <p className="small mb-0 text-muted">
              Symbiosis Institute of Technology (SIT), Section B &bull; Mithil Lanjewar &bull; Roll No: <strong>25070521105</strong>
            </p>
          </div>
          <div className="col-md-6 text-center text-md-right">
            <div className="mb-1">
              <span className="badge badge-dark border border-secondary text-warning mr-1">MongoDB 9</span>
              <span className="badge badge-dark border border-secondary text-info mr-1">Express 5</span>
              <span className="badge badge-dark border border-secondary text-primary mr-1">React 19</span>
              <span className="badge badge-dark border border-secondary text-success mr-1">Node.js v22</span>
              <span className="badge badge-dark border border-secondary text-light">Web Worker AI</span>
            </div>
            <small className="text-muted">
              &copy; {new Date().getFullYear()} Continuous Assessment 03 &bull; All Rights Reserved.
            </small>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
