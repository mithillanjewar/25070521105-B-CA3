import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import Nav from './nav';
import Home from './home';
import About from './about';
import Services from './services';
import Contact from './contact';
import LoginPage from './LoginPage';
import { api, getToken, setToken } from './api';
import './App.css';

const App = () => {
  const [user, setUser] = useState(null);
  const [token, setTok] = useState(() => getToken());

  // Restore user session on mount
  useEffect(() => {
    const savedToken = getToken();
    if (!savedToken) return;
    api('/auth/me', { token: savedToken })
      .then((data) => {
        setUser(data.user);
        setTok(savedToken);
      })
      .catch(() => {
        setToken(null);
        setTok(null);
        setUser(null);
      });
  }, []);

  const handleLogin = (data) => {
    setToken(data.token);
    setTok(data.token);
    setUser(data.user);
  };

  const signOut = () => {
    setToken(null);
    setTok(null);
    setUser(null);
  };

  return (
    <div className="app-root">
      <Nav />
      <Routes>
        <Route
          path="/"
          element={
            <Home
              user={user}
              setUser={setUser}
              token={token}
              setTok={setTok}
              signOut={signOut}
            />
          }
        />
        <Route path="/about" element={<About user={user} onSignOut={signOut} />} />
        <Route path="/services" element={<Services user={user} onSignOut={signOut} />} />
        <Route path="/contact" element={<Contact user={user} onSignOut={signOut} />} />
        <Route
          path="/login"
          element={
            <LoginPage
              user={user}
              onLogin={handleLogin}
              onGuest={() => {}}
              onSignOut={signOut}
            />
          }
        />
      </Routes>
    </div>
  );
};

export default App;
