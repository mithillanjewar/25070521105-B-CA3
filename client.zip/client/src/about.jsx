import React from 'react';
import Header from './homeComp/header';
import Footer from './homeComp/footer';
import MainContentCont from './homeComp/mainContentCont';

const About = ({ user, onSignOut }) => {
  return (
    <div style={{ background: '#0a0d14', color: '#e2e8f0', minHeight: '100vh' }}>
      <Header user={user} onSignOut={onSignOut} />
      <MainContentCont>
        <div className="container py-5">
          <div className="p-4 p-md-5 rounded shadow-lg border border-secondary" style={{ background: '#121726' }}>
            <div className="d-flex align-items-center mb-3">
              <span className="badge badge-warning mr-2 px-3 py-1 font-weight-bold">CA-03 Continuous Assessment</span>
              <span className="badge badge-dark border border-secondary text-info">MongoDB Backend</span>
            </div>
            <h1 className="display-5 font-weight-bold text-white mb-3">
              About ♞ Chess Arena
            </h1>
            <p className="lead text-muted mb-4">
              A cinematic full-stack chess web application crafted with <strong>React 19</strong>, an <strong>Express 5</strong> REST API, and a <strong>MongoDB Compass</strong> document database.
            </p>

            <hr className="border-secondary my-4" />

            <div className="row">
              <div className="col-md-6 mb-4">
                <div className="p-4 rounded h-100 border border-secondary" style={{ background: '#171e31' }}>
                  <h4 className="text-warning font-weight-bold mb-3">⚔️ The Engine &amp; AI</h4>
                  <p className="text-muted small">
                    Chess Arena features an intelligent chess engine built from first principles using the <strong>Minimax algorithm with Alpha-Beta pruning</strong>, piece-square evaluation tables, and iterative deepening.
                  </p>
                  <ul className="text-muted small pl-3 mb-0">
                    <li><strong>Squire (Easy):</strong> Fast 1-ply search with random blunder injection for beginners.</li>
                    <li><strong>Knight (Medium):</strong> 2-ply search with piece positioning heuristics and positional awareness.</li>
                    <li><strong>Grandmaster (Hard):</strong> 3-ply alpha-beta search with quiescence evaluations.</li>
                    <li><strong>Web Worker Architecture:</strong> All move calculations run in a dedicated background Web Worker thread so the user interface never stutters or drops frames.</li>
                  </ul>
                </div>
              </div>

              <div className="col-md-6 mb-4">
                <div className="p-4 rounded h-100 border border-secondary" style={{ background: '#171e31' }}>
                  <h4 className="text-info font-weight-bold mb-3">🍃 MongoDB Architecture</h4>
                  <p className="text-muted small">
                    All user accounts and finished game records are persisted in a local <strong>MongoDB Compass</strong> database on port <code>27017</code>.
                  </p>
                  <div className="table-responsive small">
                    <table className="table table-dark table-sm table-borderless mb-0">
                      <tbody>
                        <tr>
                          <td className="text-warning"><code>users</code> collection</td>
                          <td className="text-muted">Username, email, bcrypt salt hashed password (12 rounds), role ('user' | 'admin'), createdAt</td>
                        </tr>
                        <tr>
                          <td className="text-warning"><code>games</code> collection</td>
                          <td className="text-muted">user_id ObjectId reference, game mode (ai / local), difficulty, player color, outcome (win/loss/draw), move count, PGN record</td>
                        </tr>
                        <tr>
                          <td className="text-warning">Aggregation Pipeline</td>
                          <td className="text-muted">$lookup pipelines for real-time admin analytics and player win-rate statistics</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 rounded mt-2 border border-secondary" style={{ background: '#0e1320' }}>
              <h5 className="text-white font-weight-bold mb-2">🎓 Academic Submission Details</h5>
              <div className="row text-muted small">
                <div className="col-md-3 mb-2 mb-md-0">
                  <strong>Student:</strong> Mithil Lanjewar
                </div>
                <div className="col-md-3 mb-2 mb-md-0">
                  <strong>Roll No (PRN):</strong> <code>25070521105</code>
                </div>
                <div className="col-md-3 mb-2 mb-md-0">
                  <strong>Course:</strong> Web Tech Lab &bull; Sec B
                </div>
                <div className="col-md-3">
                  <strong>Guide:</strong> Prof. Somesh Chutel
                </div>
              </div>
            </div>
          </div>
        </div>
      </MainContentCont>
      <Footer />
    </div>
  );
};

export default About;
