import React from 'react';
import Header from './homeComp/header';
import Footer from './homeComp/footer';
import MainContentCont from './homeComp/mainContentCont';

const Services = ({ user, onSignOut }) => {
  const serviceCards = [
    {
      icon: "🤖",
      title: "Engine Opponent (3 Difficulties)",
      desc: "Play against Squire, Knight, or Grandmaster engine levels. Powered by a multi-threaded Web Worker so calculation never stalls animations.",
      badge: "Web Worker AI"
    },
    {
      icon: "📊",
      title: "Live Evaluation & Material Bar",
      desc: "Real-time positional evaluation meter displaying pawn advantages, captured pieces, legal move highlights, and king check alerts.",
      badge: "Live Telemetry"
    },
    {
      icon: "🍃",
      title: "MongoDB Match Tracking",
      desc: "Finished matches automatically save to your personal MongoDB match history, recording PGN moves, duration, outcome, and win streaks.",
      badge: "MongoDB Compass"
    },
    {
      icon: "👥",
      title: "Pass-and-Play Local Duels",
      desc: "Challenge a friend on the same device with board flipping, move validation, clock support, and full FIDE chess rules compliance.",
      badge: "Local 2-Player"
    },
    {
      icon: "🔊",
      title: "Synthesized Audio Engine",
      desc: "High-fidelity Web Audio API sound generator providing tactile audio feedback on moves, captures, castling, checks, and game-over.",
      badge: "Web Audio"
    },
    {
      icon: "🛡️",
      title: "Administrative Control Dashboard",
      desc: "Specialized administrator portal allowing staff to audit player registries, monitor 24-hour server activity, and review match volumes.",
      badge: "JWT Protected"
    }
  ];

  return (
    <div style={{ background: '#0a0d14', color: '#e2e8f0', minHeight: '100vh' }}>
      <Header user={user} onSignOut={onSignOut} />
      <MainContentCont>
        <div className="container py-5">
          <div className="text-center mb-5">
            <span className="badge badge-warning px-3 py-1 mb-2 font-weight-bold">FEATURES &amp; CAPABILITIES</span>
            <h1 className="display-5 font-weight-bold text-white">Chess Arena Services</h1>
            <p className="text-muted col-md-8 mx-auto">
              Engineered as a high-performance MERN platform providing comprehensive chess simulation, engine intelligence, and cloud telemetry.
            </p>
          </div>

          <div className="row">
            {serviceCards.map((svc, idx) => (
              <div className="col-md-4 mb-4" key={idx}>
                <div className="p-4 rounded h-100 border border-secondary shadow-sm" style={{ background: '#121726' }}>
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <span style={{ fontSize: '2.5rem' }}>{svc.icon}</span>
                    <span className="badge badge-dark border border-secondary text-warning small">{svc.badge}</span>
                  </div>
                  <h5 className="font-weight-bold text-white mb-2">{svc.title}</h5>
                  <p className="text-muted small mb-0">{svc.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </MainContentCont>
      <Footer />
    </div>
  );
};

export default Services;
