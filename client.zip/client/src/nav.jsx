import React from 'react';
import { NavLink } from 'react-router-dom';
import './App.css';

const Nav = () => {
  return (
    <nav className="my-nav">
      <div className="nav-container">
        <ul className="d-flex" style={{ listStyle: "none", margin: 0, padding: 0 }}>
          <li>
            <NavLink to="/" className={({ isActive }) => (isActive ? "nav-link-item active" : "nav-link-item")}>
              ♞ Arena Home
            </NavLink>
          </li>
          <li>
            <NavLink to="/about" className={({ isActive }) => (isActive ? "nav-link-item active" : "nav-link-item")}>
              About
            </NavLink>
          </li>
          <li>
            <NavLink to="/services" className={({ isActive }) => (isActive ? "nav-link-item active" : "nav-link-item")}>
              Services
            </NavLink>
          </li>
          <li>
            <NavLink to="/contact" className={({ isActive }) => (isActive ? "nav-link-item active" : "nav-link-item")}>
              Contact!
            </NavLink>
          </li>
          <li>
            <NavLink to="/login" className={({ isActive }) => (isActive ? "nav-link-item active login-btn" : "nav-link-item login-btn")}>
              Sign In / Login 🔑
            </NavLink>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Nav;
